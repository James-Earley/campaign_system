from flask import Blueprint, request, jsonify, current_app
from functools import wraps
from typing import Any
from sqlalchemy.exc import IntegrityError
from marshmallow import Schema, fields, ValidationError, validates, validate
from datetime import datetime
from app import db
from app.models.factory import get_model

# Create the blueprint if not already defined
campaigns_bp = Blueprint('campaigns', __name__, url_prefix='/campaigns')

def create_response(data: Any = None, message: str = None, status: int = 200) -> tuple:
    """Create standardized API response"""
    response = {"status": "success" if status < 400 else "error"}
    if message:
        response["message"] = message
    if data is not None:
        response["data"] = data
    return response, status

def handle_errors(f):
    """Error handling decorator"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error in {f.__name__}: {str(e)}", exc_info=True)
            return create_response(message=str(e), status=500)
    return decorated_function

class CampaignSchema(Schema):
    """Marshmallow schema for validating campaign input"""
    name = fields.String(required=True, validate=validate.Length(min=2, max=100))
    description = fields.String(validate=validate.Length(max=500), required=False, allow_none=True)
    start_date = fields.Date(required=True)
    end_date = fields.Date(required=True)

    @validates('end_date')
    def validate_end_date(self, value):
        """Custom validator to ensure end_date is after start_date"""
        if not self.data.get('start_date'):
            return
        if value <= self.data.get('start_date'):
            raise ValidationError('End date must be after start date')

@campaigns_bp.route('', methods=['POST'])
@handle_errors
def create_campaign():
    """Create a new campaign"""
    schema = CampaignSchema()
    try:
        current_app.logger.info(f"Received campaign data: {request.get_json()}")
        data = schema.load(request.get_json())
    except ValidationError as e:
        return create_response(message=str(e), status=400)

    campaign = Campaign(**data)
    db.session.add(campaign)
    db.session.commit()
    
    return create_response(
        data=schema.dump(campaign),
        message="Campaign created successfully",
        status=201
    )

@campaigns_bp.route('', methods=['GET'])
@handle_errors
def get_all_campaigns():
    """Get all campaigns with optional filtering and pagination"""
    # Pagination
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # Filtering
    query = Campaign.query
    
    if status := request.args.get('status'):
        if status == 'active':
            query = query.filter(Campaign.end_date >= datetime.now().date())
        elif status == 'completed':
            query = query.filter(Campaign.end_date < datetime.now().date())
            
    if search := request.args.get('search'):
        query = query.filter(Campaign.name.ilike(f'%{search}%'))

    # Sorting
    sort_by = request.args.get('sort_by', 'start_date')
    sort_order = request.args.get('sort_order', 'desc')
    if sort_order == 'desc':
        query = query.order_by(getattr(Campaign, sort_by).desc())
    else:
        query = query.order_by(getattr(Campaign, sort_by))

    # Execute query with pagination
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    schema = CampaignSchema(many=True)
    
    return create_response(
        data={
            "campaigns": schema.dump(pagination.items),
            "meta": {
                "page": page,
                "per_page": per_page,
                "total_pages": pagination.pages,
                "total_items": pagination.total
            }
        }
    )

@campaigns_bp.route('/<int:campaign_id>', methods=['GET'])
@handle_errors
def get_campaign(campaign_id: int):
    """Get a specific campaign"""
    campaign = Campaign.query.get_or_404(campaign_id)
    schema = CampaignSchema()
    return create_response(data=schema.dump(campaign))

@campaigns_bp.route('/<int:campaign_id>', methods=['PATCH'])
@handle_errors
def update_campaign(campaign_id: int):
    """Update a campaign"""
    campaign = Campaign.query.get_or_404(campaign_id)
    schema = CampaignSchema(partial=True)
    
    try:
        data = schema.load(request.get_json())
    except ValidationError as e:
        return create_response(message=str(e), status=400)

    for key, value in data.items():
        setattr(campaign, key, value)
        
    db.session.commit()
    return create_response(
        data=schema.dump(campaign),
        message="Campaign updated successfully"
    )

@campaigns_bp.route('/<int:campaign_id>', methods=['DELETE'])
@handle_errors
def delete_campaign(campaign_id: int):
    """Delete a campaign"""
    campaign = Campaign.query.get_or_404(campaign_id)
    db.session.delete(campaign)
    db.session.commit()
    return create_response(message="Campaign deleted successfully")

@campaigns_bp.route('/<int:campaign_id>/stats', methods=['GET'])
@handle_errors
def get_campaign_stats(campaign_id: int):
    """Get statistics for a specific campaign"""
    campaign = Campaign.query.get_or_404(campaign_id)
    
    stats = {
        "total_teams": campaign.teams.count(),
        "total_events": campaign.events.count() if hasattr(campaign, 'events') else 0,
        "total_donations": sum(d.amount for d in campaign.donations),
        "days_remaining": (campaign.end_date - datetime.now().date()).days 
            if campaign.end_date else None
    }
    
    return create_response(data=stats)