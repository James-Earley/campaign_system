# app/routes/__init__.py
from typing import Dict, List
from flask import Blueprint, Flask

# Import all blueprints
from .main import main_bp
from .citizens import citizens_bp
from .campaigns import campaigns_bp
from .events import events_bp
from .donations import donations_bp
from .volunteers import volunteers_bp
from .canvassing import canvassing_bp
from .campaign_team import campaign_team_bp
from .canvassers import canvassers_bp
from .event_staffers import event_staffers_bp
from .outreach import outreach_bp
from .voters import voters_bp 

# Define type for blueprint configuration
BlueprintConfig = Dict[str, str]
BlueprintConfigs = Dict[Blueprint, BlueprintConfig]

# Define blueprint configurations
BLUEPRINT_CONFIGS: BlueprintConfigs = {
    main_bp: {
        'url_prefix': '/',
        'description': 'Main application routes'
    },
    citizens_bp: {
        'url_prefix': '/api/v1/citizens',
        'description': 'Citizen management endpoints'
    },
    campaigns_bp: {
        'url_prefix': '/api/v1/campaigns',
        'description': 'Campaign management endpoints'
    },
    events_bp: {
        'url_prefix': '/api/v1/events',
        'description': 'Event management endpoints'
    },
    donations_bp: {
        'url_prefix': '/api/v1/donations',
        'description': 'Donation tracking endpoints'
    },
    volunteers_bp: {
        'url_prefix': '/api/v1/volunteers',
        'description': 'Volunteer management endpoints'
    },
    canvassing_bp: {
        'url_prefix': '/api/v1/canvassing',
        'description': 'Canvassing operation endpoints'
    },
    campaign_team_bp: {
        'url_prefix': '/api/v1/campaign-team',
        'description': 'Campaign team management endpoints'
    },
    canvassers_bp: {
        'url_prefix': '/api/v1/canvassers',
        'description': 'Canvasser management endpoints'
    },
    event_staffers_bp: {
        'url_prefix': '/api/v1/event-staffers',
        'description': 'Event staff management endpoints'
    },
    outreach_bp: {
        'url_prefix': '/api/v1/outreach',
        'description': 'Outreach management endpoints'
    },
    voters_bp: {
        'url_prefix': '/api/v1/voters',
        'description': 'Voters management endpoints'
    }
}

# List of all available blueprints for export
__all__ = [
    'main_bp',
    'citizens_bp',
    'campaigns_bp',
    'event_bp',
    'donations_bp',
    'volunteers_bp',
    'canvassing_bp',
    'campaign_team_bp',
    'canvassers_bp',
    'event_staffers_bp',
    'outreach_bp',
    'voters_bp',
    'BLUEPRINT_CONFIGS',
    'register_blueprints'
]

def register_blueprints(app: Flask) -> List[str]:
    """
    Register all blueprints with the application.
    
    Args:
        app: Flask application instance
        
    Returns:
        List of registered blueprint names
        
    Raises:
        Exception: If blueprint registration fails
    """
    registered: List[str] = []
    
    for blueprint, config in BLUEPRINT_CONFIGS.items():
        try:
            app.register_blueprint(
                blueprint,
                url_prefix=config['url_prefix']
            )
            registered.append(blueprint.name)
        except Exception as e:
            app.logger.error(
                f"Failed to register blueprint {blueprint.name}: {str(e)}",
                exc_info=True
            )
            raise
            
    app.logger.info(f"Successfully registered blueprints: {', '.join(registered)}")
    return registered

def get_route_documentation() -> Dict[str, str]:
    """
    Get documentation for all routes.
    
    Returns:
        Dictionary mapping blueprint names to their descriptions
    """
    return {
        blueprint.name: config['description'] 
        for blueprint, config in BLUEPRINT_CONFIGS.items()
    }