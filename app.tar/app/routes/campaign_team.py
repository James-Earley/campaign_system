# app/routes/campaign_team.py
from flask import Blueprint, request, current_app
from marshmallow import Schema, fields, validate
from app import db
from app.models.factory import get_model
from app.models.enums import VolunteerStatus
from typing import Dict, List, Any
from functools import wraps

campaign_team_bp = Blueprint('campaign_team', __name__)
CampaignTeam = get_model('CampaignTeam')

# Validation Schema
class CampaignTeamSchema(Schema):
    campaign_id = fields.Integer(required=True)
    name = fields.String(required=True, validate=validate.Length(min=1, max=100))
    description = fields.String(allow_none=True)
    contact_email = fields.Email(allow_none=True)
    contact_phone = fields.String(validate=validate.Length(max=20), allow_none=True)
    team_size = fields.Integer(allow_none=True, validate=validate.Range(min=1))
    staff_type = fields.String(required=True, validate=validate.OneOf(['FULL_TIME', 'PART_TIME', 'VOLUNTEER']))
    status = fields.String(validate=validate.OneOf([status.value for status in VolunteerStatus]))

# Response Helper
def create_response(data: Any = None, message: str = None, status: int = 200) -> tuple:
    response = {"status": "success" if status < 400 else "error"}
    if message:
        response["message"] = message
    if data is not None:
        response["data"] = data
    return response, status

# Error Handler Decorator
def handle_errors(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error in {f.__name__}: {str(e)}", exc_info=True)
            return create_response(message=str(e), status=500)
    return decorated_function

@campaign_team_bp.route('/', methods=['POST'])
@handle_errors
def create_campaign_team():
    """Create a new campaign team"""
    schema = CampaignTeamSchema()
    try:
        data = schema.load(request.get_json())
    except Exception as e:
        return create_response(
            message=f"Validation error: {str(e)}", 
            status=400
        )

    # Check for existing team
    existing_team = CampaignTeam.query.filter_by(
        campaign_id=data['campaign_id'], 
        name=data['name']
    ).first()
    
    if existing_team:
        return create_response(
            message="A team with this name already exists in this campaign",
            status=400
        )

    team = CampaignTeam(**data)
    db.session.add(team)
    db.session.commit()

    return create_response(
        data=schema.dump(team),
        message="Campaign team created successfully",
        status=201
    )

@campaign_team_bp.route('/', methods=['GET'])
@handle_errors
def get_all_campaign_teams():
    """Get all campaign teams with optional filtering and pagination"""
    # Pagination parameters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # Filtering parameters
    campaign_id = request.args.get('campaign_id', type=int)
    staff_type = request.args.get('staff_type')
    status = request.args.get('status')

    query = CampaignTeam.query

    # Apply filters
    if campaign_id:
        query = query.filter_by(campaign_id=campaign_id)
    if staff_type:
        query = query.filter_by(staff_type=staff_type)
    if status:
        query = query.filter_by(status=status)

    # Apply pagination
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    schema = CampaignTeamSchema(many=True)

    return create_response(
        data={
            "teams": schema.dump(pagination.items),
            "meta": {
                "page": page,
                "per_page": per_page,
                "total_pages": pagination.pages,
                "total_items": pagination.total
            }
        }
    )

@campaign_team_bp.route('/<int:team_id>', methods=['GET'])
@handle_errors
def get_campaign_team(team_id: int):
    """Get a specific campaign team by ID"""
    team = CampaignTeam.query.get_or_404(team_id)
    schema = CampaignTeamSchema()
    return create_response(data=schema.dump(team))

@campaign_team_bp.route('/<int:team_id>', methods=['PATCH'])
@handle_errors
def update_campaign_team(team_id: int):
    """Update a campaign team"""
    team = CampaignTeam.query.get_or_404(team_id)
    schema = CampaignTeamSchema(partial=True)
    
    try:
        data = schema.load(request.get_json())
    except Exception as e:
        return create_response(message=f"Validation error: {str(e)}", status=400)

    # Check name uniqueness if name is being updated
    if 'name' in data and data['name'] != team.name:
        existing_team = CampaignTeam.query.filter_by(
            campaign_id=team.campaign_id,
            name=data['name']
        ).first()
        if existing_team:
            return create_response(
                message="A team with this name already exists in this campaign",
                status=400
            )

    for key, value in data.items():
        setattr(team, key, value)

    db.session.commit()
    return create_response(
        data=schema.dump(team),
        message="Campaign team updated successfully"
    )

@campaign_team_bp.route('/<int:team_id>', methods=['DELETE'])
@handle_errors
def delete_campaign_team(team_id: int):
    """Delete a campaign team"""
    team = CampaignTeam.query.get_or_404(team_id)
    db.session.delete(team)
    db.session.commit()
    return create_response(message="Campaign team deleted successfully")

# Utility endpoint for team stats
@campaign_team_bp.route('/<int:team_id>/stats', methods=['GET'])
@handle_errors
def get_team_stats(team_id: int):
    """Get statistics for a specific team"""
    team = CampaignTeam.query.get_or_404(team_id)
    
    stats = {
        "total_members": team.members.count(),
        "active_members": team.members.filter_by(status=VolunteerStatus.ACTIVE.value).count(),
        "total_sessions": team.canvassing_sessions.count(),
        "completed_sessions": team.canvassing_sessions.filter_by(
            task_status="COMPLETED"
        ).count()
    }
    
    return create_response(data=stats)