# app/models/volunteer_assignment.py
from datetime import datetime

def create_volunteer_assignment_model(db):
    """Creates the VolunteerAssignment model."""

    class VolunteerAssignment(db.Model):
        __tablename__ = 'volunteer_assignments'
        __table_args__ = {'extend_existing': True}

        id = db.Column(db.Integer, primary_key=True)
        volunteer_id = db.Column(db.Integer, db.ForeignKey('volunteers.id'), nullable=False)
        campaign_event_id = db.Column(db.Integer, db.ForeignKey('campaign_events.id'), nullable=True)
        canvassing_session_id = db.Column(db.Integer, db.ForeignKey('canvassing_sessions.id'), nullable=True)
        event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=True)

        task = db.Column(db.String(255), nullable=False)
        assigned_at = db.Column(db.DateTime, default=datetime.utcnow)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

        # Define relationships
        volunteer = db.relationship('Volunteer', back_populates='assignments')
        
        # Add missing relationship to CampaignEvent
        campaign_event = db.relationship('CampaignEvent', 
            backref=db.backref('volunteer_assignments', lazy='dynamic'),
            foreign_keys=[campaign_event_id])

    # Add missing relationship to CanvassingSession
        canvassing_session = db.relationship('CanvassingSession',
            backref=db.backref('volunteer_assignments', lazy='dynamic'),
            foreign_keys=[canvassing_session_id])
    

        #FIXED: Change the backref name to avoid conflict
        event = db.relationship('Event', back_populates='volunteer_assignments')


        def __repr__(self):
            return f'<VolunteerAssignment {self.volunteer_id}: {self.task}>'

    return VolunteerAssignment
