# app/models/campaign.py
from datetime import datetime

def create_campaign_model(db):
    """Creates the Campaign model."""
    
    class Campaign(db.Model):
        __tablename__ = 'campaigns'
        __table_args__ = {'extend_existing': True}

        id = db.Column(db.Integer, primary_key=True)
        name = db.Column(db.String(100), nullable=False)
        description = db.Column(db.Text)
        start_date = db.Column(db.Date, nullable=False)  # Changed to Date type
        end_date = db.Column(db.Date)                    # Changed to Date type
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

        def __repr__(self):
            return f'<Campaign {self.name}>'

    return Campaign