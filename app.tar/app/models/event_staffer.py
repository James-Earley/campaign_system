# app/models/event_staffer.py
from datetime import datetime
from .enums import EventStatus

def create_event_staffer_model(db):
    """Creates the EventStaffer model with enhanced role tracking."""
    
    class EventStaffer(db.Model):
        __tablename__ = 'event_staffers'
        __table_args__ = {'extend_existing': True}
        
        id = db.Column(db.Integer, primary_key=True)
        event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)
        volunteer_id = db.Column(db.Integer, db.ForeignKey('volunteers.id'), nullable=False)
        role = db.Column(db.String(50), nullable=False)  # e.g., 'coordinator', 'security', 'registration'
        shift_start = db.Column(db.DateTime, nullable=False)
        shift_end = db.Column(db.DateTime, nullable=False)
        status = db.Column(db.String(20), default='scheduled')  # e.g., 'scheduled', 'checked-in', 'completed'
        notes = db.Column(db.Text)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
        
        status = db.Column(
            db.Enum(EventStatus),
            default=EventStatus.SCHEDULED,
            nullable=False
        )
        # Relationships
        event = db.relationship('Event', backref=db.backref(
            'staff_assignments',  # Changed backref to avoid conflict
            lazy='dynamic',
            cascade='all, delete-orphan'
        ))
        volunteer = db.relationship('Volunteer', backref=db.backref(
            'event_assignments',
            lazy='dynamic',
            cascade='all, delete-orphan'
        ))

        def __repr__(self):
            return f'<EventStaffer {self.volunteer_id} for Event {self.event_id}>'

        @property
        def is_current(self):
            """Check if the shift is currently active."""
            now = datetime.utcnow()
            return self.shift_start <= now <= self.shift_end

    return EventStaffer
