def create_event_model(db):
    """Creates the Event model with proper relationships."""
    
    class Event(db.Model):
        __tablename__ = 'events'
        __table_args__ = {'extend_existing': True}

        id = db.Column(db.Integer, primary_key=True)
        campaign_id = db.Column(db.Integer, db.ForeignKey('campaigns.id'), nullable=False) 
        name = db.Column(db.String(100), nullable=False)
        description = db.Column(db.Text)
        date = db.Column(db.DateTime, nullable=False)
        location = db.Column(db.String(255), nullable=False)
        event_type = db.Column(db.String(50))
        capacity = db.Column(db.Integer)
        
        # Fixing backref naming conflict
        staffers = db.relationship('EventStaffer', backref='event_staffing', lazy='dynamic')
        volunteer_assignments = db.relationship('VolunteerAssignment', back_populates='event', lazy='dynamic')


        def __repr__(self):
            return f'<Event {self.name}>'

    return Event
