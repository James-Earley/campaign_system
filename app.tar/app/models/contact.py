from datetime import datetime

def create_contact_model(db):
    class Contact(db.Model):
        __tablename__ = 'contacts'
        id = db.Column(db.Integer, primary_key=True)
        citizen_id = db.Column(db.Integer, db.ForeignKey('citizens.id'), nullable=False)
        contact_date = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
        outcome = db.Column(db.String(255), nullable=False)
        follow_up_required = db.Column(db.Boolean, default=False)
        contact_method = db.Column(db.String(50), nullable=False)

        citizen = db.relationship('Citizen', backref=db.backref('contacts', lazy=True))
    return Contact