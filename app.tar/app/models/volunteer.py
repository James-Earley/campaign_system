# app/models/volunteer.py
from datetime import datetime

def create_volunteer_model(db):
    """Creates the Volunteer model."""
    
    class Volunteer(db.Model):
        __tablename__ = 'volunteers'
        __table_args__ = {'extend_existing': True}

        id = db.Column(db.Integer, primary_key=True)
        first_name = db.Column(db.String(100), nullable=False)
        last_name = db.Column(db.String(100), nullable=False)
        email = db.Column(db.String(100), unique=True, nullable=False)
        phone = db.Column(db.String(20))
        address = db.Column(db.String(255))
        city = db.Column(db.String(100))
        state = db.Column(db.String(2))
        zip_code = db.Column(db.String(10))
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

        assignments = db.relationship(
            'VolunteerAssignment', 
            back_populates='volunteer',
            lazy='dynamic'
        )

        def __repr__(self):
            return f'<Volunteer {self.first_name} {self.last_name}>'

    return Volunteer