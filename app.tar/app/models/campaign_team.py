# app/models/campaign_team.py
from datetime import datetime
from .enums import VolunteerStatus

_model = None

def create_campaign_team_model(db):
    class CampaignTeam(db.Model):
        __tablename__ = 'campaign_team'
        __table_args__ = (
            db.UniqueConstraint('campaign_id', 'name', name='uix_team_campaign_name'),
            {'extend_existing': True}
        )

        id = db.Column(db.Integer, primary_key=True)
        campaign_id = db.Column(db.Integer, db.ForeignKey('campaigns.id'), nullable=False)
        name = db.Column(db.String(100), nullable=False)
        description = db.Column(db.Text)
        contact_email = db.Column(db.String(100))
        contact_phone = db.Column(db.String(20))
        team_size = db.Column(db.Integer)
        staff_type = db.Column(db.String(50), nullable=False)
        status = db.Column(
            db.Enum(VolunteerStatus),
            default=VolunteerStatus.ACTIVE,
            nullable=False
        )
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

        # ... rest of the model ...

    return CampaignTeam