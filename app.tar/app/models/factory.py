from functools import lru_cache
from flask import Blueprint, request, jsonify
from flask_sqlalchemy import SQLAlchemy
import logging

logger = logging.getLogger(__name__)

db = SQLAlchemy()

class ModelFactory:
    """
    Singleton factory for managing model initialization and access.
    Ensures consistent model loading across the application.
    """
    _instance = None
    _initialized = False
    _models = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ModelFactory, cls).__new__(cls)
        return cls._instance

    def initialize(self, db: SQLAlchemy):
        """Initialize all models in the correct dependency order."""
        if self._initialized:
            return

        # Import model creation functions
        from .citizen import create_citizen_model
        from .campaign import create_campaign_model
        from .campaign_team import create_campaign_team_model
        from .campaign_event import create_campaign_event_model
        from .canvassing_session import create_canvassing_session_model
        from .volunteer import create_volunteer_model
        from .volunteer_assignment import create_volunteer_assignment_model
        from .donation import create_donation_model
        from .outreach import create_outreach_model
        from .address import create_address_model
        from .contact import create_contact_model
        from .voting_intention import create_voting_intention_model
        from .voter import create_voter_model
        from .canvasser import create_canvasser_model
        from .event import create_event_model
        from .event_staffer import create_event_staffer_model
        from .enums import TaskStatus, VolunteerStatus, EventStatus, DonationStatus

        # Initialize models in dependency order
        self._models.update({
            'Address': create_address_model(db),
            'Citizen': create_citizen_model(db),
            'Campaign': create_campaign_model(db),
            'CampaignTeam': create_campaign_team_model(db),
            'CampaignEvent': create_campaign_event_model(db),
            'CanvassingSession': create_canvassing_session_model(db),
            'Volunteer': create_volunteer_model(db),
            'VolunteerAssignment': create_volunteer_assignment_model(db),
            'Donation': create_donation_model(db),
            'Outreach': create_outreach_model(db),
            'Contact': create_contact_model(db),
            'VotingIntention': create_voting_intention_model(db),
            'Voter': create_voter_model(db),
            'Canvasser': create_canvasser_model(db),
            'Event': create_event_model(db),
            'EventStaffer': create_event_staffer_model(db)
        })

        self._initialized = True
        logger.info("Model factory initialized successfully")

    @lru_cache(maxsize=None)
    def get_model(self, model_name: str):
        """Get a model by name. Results are cached for performance."""
        if not self._initialized:
            raise RuntimeError("ModelFactory not initialized. Call initialize() first.")
        
        model = self._models.get(model_name)
        if model is None:
            raise ValueError(f"Model '{model_name}' not found")
            
        return model

    def clear_cache(self):
        """Clear the model cache."""
        self._models.clear()
        self.get_model.cache_clear()
        self._initialized = False

# Create singleton instance
model_factory = ModelFactory()

# Helper function for routes
def get_model(model_name: str):
    """Helper function to get a model by name"""
    return model_factory.get_model(model_name)

# Define API routes following the correct structure
voters_bp = Blueprint('voters', __name__)

@voters_bp.route('/', methods=['GET'])
def get_voters():
    Voter = get_model('Voter')
    voters = Voter.query.all()
    return jsonify([{
        "id": voter.voter_id,
        "citizen_id": voter.citizen_id,
        "registration_date": voter.registration_date,
        "last_known_vote_intention": voter.last_known_vote_intention,
        "last_intention_change_date": voter.last_intention_change_date
    } for voter in voters]), 200

@voters_bp.route('/', methods=['POST'])
def create_voter():
    Voter = get_model('Voter')
    data = request.get_json()
    voter = Voter(
        citizen_id=data['citizen_id'],
        registration_date=data['registration_date'],
        last_known_vote_intention=data.get('last_known_vote_intention'),
        last_intention_change_date=data.get('last_intention_change_date')
    )
    db.session.add(voter)
    db.session.commit()
    return jsonify({"message": "Voter added successfully!"}), 201
