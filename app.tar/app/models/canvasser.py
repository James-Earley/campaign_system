# app/models/canvasser.py
from datetime import datetime

def create_canvasser_model(db):
    """Creates the Canvasser model with proper foreign key relationships."""
    
    class Canvasser(db.Model):
        __tablename__ = 'canvassers'
        __table_args__ = {'extend_existing': True}
        
        id = db.Column(db.Integer, primary_key=True)
        citizen_id = db.Column(db.Integer, db.ForeignKey('citizens.id'), nullable=False)  # Changed from voter_id
        previous_intention = db.Column(db.String(50))
        current_intention = db.Column(db.String(50))
        last_contact_date = db.Column(db.DateTime)
        notes = db.Column(db.Text)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

        # Define relationship to Citizen model instead of Voter
        citizen = db.relationship('Citizen', backref=db.backref('canvasser_info', lazy=True))

        def __repr__(self):
            return f'<Canvasser {self.id} for Citizen {self.citizen_id}>'

    return Canvasser