def create_address_model(db):
    class Address(db.Model):
        __tablename__ = 'addresses'
        __table_args__ = {'extend_existing': True}
        
        id = db.Column(db.Integer, primary_key=True)
        street = db.Column(db.String(255), nullable=False)
        postcode = db.Column(db.String(20), nullable=False)
        city = db.Column(db.String(100), nullable=False)
        county = db.Column(db.String(100), nullable=True)

        def __repr__(self):
            return f'<Address {self.street}, {self.city}>'

    return Address