# app/__init__.py
from flask import Flask
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy
from app.models.factory import model_factory
import os

db = SQLAlchemy()
migrate = Migrate()

def create_app():
    app = Flask(__name__)
    
    # Enable debug mode
    app.config['DEBUG'] = True

    # Set up configuration
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv(
        'DATABASE_URL',
        f'sqlite:///{os.path.join(os.path.dirname(__file__), "instance", "campaign.db")}'
    )
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SQLALCHEMY_ECHO'] = True  # Log SQL queries

    # Ensure instance directory exists
    os.makedirs(os.path.join(os.path.dirname(__file__), 'instance'), exist_ok=True)

    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)

    with app.app_context():
        # Initialize models through factory
        model_factory.initialize(db)
        
        # Import and register blueprints
        from app.routes import register_blueprints
        register_blueprints(app)
        
        # Create tables
        db.create_all()

    return app

app = create_app()